#!/bin/bash
javacc Imron_Gamidli.jj
javac *.java