#!/bin/bash
rm *.java
rm *.class